<?php

/*

Created by MakeJar https://www.makejar.com/

*/

include 'includes/app.php';

// if not installed then go to the install
if (!is_file('includes/config.php')) {
    header('Location: install.php');
    exit;
}

// if not logged then go to the login
if (!isset($_SESSION['jp']['logged'])) {
    header('Location: login.php');
    exit;
}

// sendlog
if (!isset($_SESSION['jp']['sendlog'])) {
    $_SESSION['jp']['sendlog'] = [];
}


switch ($act) {
    case 'send':
        //
        $user_address = $_POST['user_address'];
        $amount_satoshi = $_POST['amount_satoshi'];
        $currency_fiat = $_POST['currency_fiat'];
        $currency_crypto = $_POST['currency_crypto'];
        $conversion_fee = $_POST['conversion_fee'];
        $currency_gateway = $_POST['currency_gateway'];
        $conversion_fee = $_POST['conversion_fee'];
        $amount_fiat = $_POST['amount_fiat'];
        $currency_fiat = $_POST['currency_fiat'];
        //
        $_SESSION['jp']['DEFAULT_CURRENCY_FIAT'] = $currency_fiat;
        $_SESSION['jp']['DEFAULT_CURRENCY_CRYPTO'] = $currency_crypto;
        $_SESSION['jp']['DEFAULT_CONVERSION_FEE'] = $conversion_fee;
        $_SESSION['jp']['DEFAULT_GATEWAY'] = $currency_gateway;
        //
        switch ($currency_gateway) {
            case 'FaucetPay':
                $crypto_class = new FaucetPay($settings['FP_API_KEY'], $currency_crypto);
                $response = $crypto_class->send($user_address, $amount_satoshi, '');
                if ((isset($response)) && (is_array($response))) {
                    $response['user_address'] = $user_address;
                    $response['amount_satoshi'] = $amount_satoshi;
                    $response['conversion_fee'] = $conversion_fee;
                    $response['amount_fiat'] = $amount_fiat;
                    $response['currency_fiat'] = $currency_fiat;
                    if ($response['success']) {
                        $_SESSION['jp']['message'][] = ['status' => 'success', 'message' => $response['message']];
                    } else {
                        $_SESSION['jp']['message'][] = ['status' => 'danger', 'message' => $response['message']];
                    }
                    if (isset($response['balance_bitcoin'])) {
                        $_SESSION['FP_BALANCE_' . $currency_crypto] = $response['balance_bitcoin'];
                    }
                    if (!isset($response['html_coin'])) {
                        $response['html_coin'] = $response['html'];
                    }
                    // add to sendlog
                    $_SESSION['jp']['sendlog'][] = $response;
                } else {
                    $_SESSION['jp']['message'][] = ['status' => 'danger', 'message' => 'Connection lost. Check the FaucetPay.io if the transaction was successful.'];
                }
                header('Location: .');
                exit;
                break;
        }
        break;
}

// set shown default values
$default_values = [];
$default_values['DEFAULT_GATEWAY'] = '';
$default_values['DEFAULT_CURRENCY_FIAT'] = $settings['DEFAULT_CURRENCY_FIAT'];
$default_values['DEFAULT_CURRENCY_CRYPTO'] = $settings['DEFAULT_CURRENCY_CRYPTO'];
$default_values['DEFAULT_CONVERSION_FEE'] = $settings['DEFAULT_CONVERSION_FEE'];

if (isset($_SESSION['jp']['DEFAULT_GATEWAY'])) {
    $default_values['DEFAULT_GATEWAY'] = $_SESSION['jp']['DEFAULT_GATEWAY'];
}
if (isset($_SESSION['jp']['DEFAULT_CURRENCY_FIAT'])) {
    $default_values['DEFAULT_CURRENCY_FIAT'] = $_SESSION['jp']['DEFAULT_CURRENCY_FIAT'];
}
if (isset($_SESSION['jp']['DEFAULT_CURRENCY_CRYPTO'])) {
    $default_values['DEFAULT_CURRENCY_CRYPTO'] = $_SESSION['jp']['DEFAULT_CURRENCY_CRYPTO'];
}
if (isset($_SESSION['jp']['DEFAULT_CONVERSION_FEE'])) {
    $default_values['DEFAULT_CONVERSION_FEE'] = $_SESSION['jp']['DEFAULT_CONVERSION_FEE'];
}


include 'includes/template-top.php';

?>

<div class="center-box">
    <form class="form-center" method="post">
        <input type="hidden" name="act" value="send" />
        <input type="hidden" name="rate" value="0" id="currencyRate" />
        <div class="text-center mb-4">
            <img class="mb-4" src="images/jarpay.svg" alt="Jar Pay" width="72" height="72" />
            <h1 class="h3 mb-3 font-weight-normal"><?php echo $jarpay_name; ?> - Send</h1>
            <p>Please enter the details below</p>
        </div>

        <?php

        if ((is_array($_SESSION['jp']['message'])) && (count($_SESSION['jp']['message']) > 0)) {
            foreach ($_SESSION['jp']['message'] as $message) {
                echo '<div class="alert alert-' . $message['status'] . '">' . $message['message'] . '</div>';
            }
            $_SESSION['jp']['message'] = [];
        }

        ?>
        <div class="form-label-group">
            <select name="currency_gateway" id="selectGateway" class="form-control" placeholder="Gateway">
                <?php
                foreach ($gateways_array as $gateway => $available_cryptos_array) {
                    $selected = '';
                    if ($gateway == $default_values['DEFAULT_GATEWAY']) {
                        $selected = ' selected="selected"';
                    }
                    echo '<option value="' . $gateway . '"' . $selected . '>' . $gateway . '</option>';
                }
                ?>
            </select>
            <label for="selectGateway">Gateway</label>
            <?php
            foreach ($gateways_array as $gateway => $available_cryptos_array) {
                echo '<input type="hidden" name="g_avc_' . $gateway . '" id="g_avc_' . $gateway . '" value="' . implode(',', $available_cryptos_array) . '" />';
            }
            ?>
        </div>

        <div class="form-label-group">
            <select name="currency_fiat" id="selectDCF" class="form-control" placeholder="Currency Fiat">
                <?php
                foreach ($currencies_fiat as $currency) {
                    $selected = '';
                    if ($currency == $default_values['DEFAULT_CURRENCY_FIAT']) {
                        $selected = ' selected="selected"';
                    }
                    echo '<option value="' . $currency . '"' . $selected . '>' . $currency . '</option>';
                }
                ?>
            </select>
            <label for="selectDCF">Currency Fiat</label>
        </div>

        <div class="form-label-group">
            <select name="currency_crypto" id="selectDCC" class="form-control" placeholder="Currency Crypto">
                <?php
                foreach ($currencies_crypto_array as $currency) {
                    $selected = '';
                    if ($currency == $default_values['DEFAULT_CURRENCY_CRYPTO']) {
                        $selected = ' selected="selected"';
                    }
                    echo '<option value="' . $currency . '"' . $selected . '>' . $currency . '</option>';
                }
                ?>
            </select>
            <label for="selectDCC">Currency Crypto</label>
        </div>

        <div class="form-label-group">
            <input type="number" min="0" max="99" step=".01" name="conversion_fee" id="ConversionFee" class="form-control" placeholder="Conversion Fee (in %)" value="<?php echo $default_values['DEFAULT_CONVERSION_FEE']; ?>" />
            <label for="ConversionFee">Conversion Fee (in %)</label>
        </div>

        <div class="form-label-group">
            <input type="input" name="user_address" id="inputUA" class="form-control" placeholder="User Address" required autofocus />
            <label for="inputUA">User Address</label>
        </div>

        <div class="form-label-group">
            <input type="number" step=".0001" name="amount_fiat" id="inputAF" class="form-control" placeholder="Amount Fiat" value="" required />
            <label for="inputAF">Amount Fiat</label>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <div class="form-label-group">
                    <input type="number" step=".00000001" name="amount_crypto" id="inputAC" class="form-control" placeholder="Amount Crypto" value="" required />
                    <label for="inputAC" style="font-size: 13px;">Amount Crypto</label>
                </div>
            </div>

            <div class="col-md-6 mb-3">
                <div class="form-label-group">
                    <input type="number" step=".00000001" name="amount_satoshi" id="inputACs" class="form-control" placeholder="Amount Crypto" value="" required />
                    <label for="inputACs" style="font-size: 13px;">Amount Crypto</label>
                </div>
            </div>
        </div>

        <button class="btn btn-lg btn-primary btn-block" type="submit">Send</button>
    </form>
    <?php

    $sendlog_array = $_SESSION['jp']['sendlog'];
    $sendlog_array = array_reverse($sendlog_array);

    if (count($sendlog_array) > 0) {
        echo '<h3 style="margin-top: 10px;">Payout history</h3>';
        foreach ($sendlog_array as $sendlog_item) {
            echo '<div>';
            echo '<div>' . htmlspecialchars($sendlog_item['user_address']) . '</div>';
            echo '<div class="text-muted">[ ' . $sendlog_item['amount_fiat'] . '' . $sendlog_item['currency_fiat'] . ' (' . $sendlog_item['conversion_fee'] . '% fee) ]</div>';
            echo $sendlog_item['html_coin'];
            echo '</div>';
            echo '<hr />';
        }
    } else {
        echo '<br />';
        echo '<div class="alert alert-dark">';
        echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">';
        echo '<span aria-hidden="true">&times;</span>';
        echo '</button>';
        echo '<b>No address to test?</b><br />';
        echo '<div class="text-muted">Make the developer happy:</div>';
        echo '<div class="dev-tip dev-FaucetPay">1MakeJar79wqjDyqNagES7AaX9GwdtfqvS</div>';
        echo '</div>';
    }

    ?>
    <form action="login.php" class="form-center" method="post">
        <input type="hidden" name="act" value="logout" />
        <button class="btn btn-lg btn-warning btn-block" style="margin-top: 10px;" type="submit">Logout</button>
    </form>
</div>

<script type="text/javascript">
    $(function() {
        $('#selectGateway').on('change', function() {
            $('#selectDCC option').css('display', '');
            var currencies_array = $('#g_avc_' + $(this).val()).val().split(',');
            $('#selectDCC> option').each(function() {
                if (!currencies_array.includes($(this).val())) {
                    $(this).css('display', 'none');
                }
            });
            if ($('#selectDCC> option:selected').css('display') == 'none') {
                $('#selectDCC> option').each(function() {
                    if ($(this).css('display') != 'none') {
                        $(this).prop('selected', true);
                        return false;
                    }
                });
            }
        });
        $('#selectGateway,#selectDCC').on('change', function() {
            $('#inputUA').attr('placeholder', $('#selectGateway').val() + ' ' + $('#selectDCC').val() + ' Address');
            $('label[for="inputUA"]').html($('#selectGateway').val() + ' ' + $('#selectDCC').val() + ' Address');
            $('.dev-tip').css('display', 'none');
            $('.dev-' + $('#selectGateway').val()).css('display', '');
        });

        $('#selectDCF,#selectDCC,#selectGateway').on('change', function() {
            $.ajax({
                method: 'POST',
                url: 'ajax.php',
                data: {
                    selectDCF: $('#selectDCF').val(),
                    selectDCC: $('#selectDCC').val(),
                    selectGateway: $('#selectGateway').val()
                }
            }).done(function(dataJson) {
                var data = JSON.parse(dataJson);
                $('#currencyRate').val(data.rate);
                $('#inputAF').attr('placeholder', 'Amount ' + $('#selectDCF').val());
                $('label[for="inputAF"]').html('' + $('#selectDCF').val() + ' [' + ((Math.round((1 / data.rate) * 100000000) / 100000000).toFixed(8)) + ' ' + $('#selectDCC').val() + '/' + $('#selectDCF').val() + ']');
                $('#inputAC').attr('placeholder', 'Amount ' + $('#selectDCC').val());
                $('label[for="inputAC"]').html('' + $('#selectDCC').val() + ' [' + ((Math.round(data.rate * 100000000) / 100000000)) + ' ' + $('#selectDCF').val() + '/' + $('#selectDCC').val() + ']');

                $('#inputACs').attr('placeholder', 'Amount ' + $('#selectDCC').val() + ' satoshi');
                $('label[for="inputACs"]').html('' + $('#selectDCC').val() + ' satoshi'); // ['+((Math.round(data.rate) / 100000000).toFixed(8))+' '+$('#selectDCF').val()+'/sat]');

                $('#selectGateway').attr('placeholder', 'Gateway ' + ((data.balance / 100000000).toFixed(8)) + ' ' + $('#selectDCC').val() + '');
                $('label[for="selectGateway"]').html('Gateway ' + ((data.balance / 100000000).toFixed(8)) + ' ' + $('#selectDCC').val() + '');
                $('#inputAF').change();
            });
        });

        $('#inputAF,#ConversionFee').on('change keyup', function() {
            if ((!isNaN($('#inputAF').val())) && ($('#inputAF').val())) {
                var fiatValue = parseFloat($('#inputAF').val());
                var result = fiatValue * ((1 / $('#currencyRate').val()) * 100000000);
                if ((!isNaN($('#ConversionFee').val())) && ($('#ConversionFee').val())) {
                    var fee = parseFloat($('#ConversionFee').val());
                    result = result / (1 + fee / 100);
                }
                $('#inputACs').val(Math.round(result));
                result = (Math.round(result) / 100000000).toFixed(8);
                $('#inputAC').val(result);
            }
        });

        $('#inputAC').on('change keyup', function() {
            var result = 0;
            if ((!isNaN($('#inputAC').val())) && ($('#inputAC').val())) {
                $('#inputACs').val($('#inputAC').val() * 100000000);
                var fiatValue = parseFloat($('#inputAC').val() * 100000000);
                result = fiatValue * ($('#currencyRate').val() / 100000000);
                if ((!isNaN($('#ConversionFee').val())) && ($('#ConversionFee').val())) {
                    var fee = parseFloat($('#ConversionFee').val());
                    result = result * (1 + fee / 100);
                }
                result = Math.round(result * 10000) / 10000;
            }
            $('#inputAF').val(result);
        });

        $('#inputACs').on('change keyup', function() {
            if ((!isNaN($('#inputACs').val())) && ($('#inputACs').val())) {
                $('#inputAC').val(($('#inputACs').val() / 100000000).toFixed(8)).change();
            }
        });

        $('#selectDCC').change();
        $('#selectGateway').change();
    });
</script>
<?php

include 'includes/template-bottom.php';

?>