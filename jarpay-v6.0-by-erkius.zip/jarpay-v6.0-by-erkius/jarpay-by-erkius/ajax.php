<?php

/*

Created by MakeJar https://www.makejar.com/

*/

include 'includes/app.php';

// if not logged then exit
if (!isset($_SESSION['jp']['logged'])) {
    exit;
}

$selectDCF = '';
if (isset($_POST['selectDCF'])) {
    $selectDCF = $_POST['selectDCF'];
}
$selectDCC = '';
if (isset($_POST['selectDCC'])) {
    $selectDCC = $_POST['selectDCC'];
}

if ((empty($selectDCF)) || (empty($selectDCC))) {
    exit;
}

// get currency IDs
$currency_id = array_search($selectDCC, $currencies_crypto_array);

// check coingecko
if ((!isset($_SESSION['jp'][$selectDCF.'_'.$selectDCC.'_RATE'])) || ($_SESSION['jp'][$selectDCF.'_'.$selectDCC.'_RATE_TIME']<time()-600)) {
    $json_data = file_get_contents('https://api.coingecko.com/api/v3/coins/'.$currency_id.'?localization=en&sparkline=false');
    $response_data = json_decode($json_data, true);
    if (isset($response_data['market_data']['current_price'][strtolower($selectDCF)])) {
        $_SESSION['jp'][$selectDCF.'_'.$selectDCC.'_RATE'] = $response_data['market_data']['current_price'][strtolower($selectDCF)];
        $_SESSION['jp'][$selectDCF.'_'.$selectDCC.'_RATE_TIME'] = time();
    }
}

$data['rate'] = $_SESSION['jp'][$selectDCF.'_'.$selectDCC.'_RATE'];

// now get the balance
switch ($_POST['selectGateway']) {
    case 'FaucetPay':
        if (isset($_SESSION['jp']['FP_BALANCE_'.$selectDCC])) {
            $data['balance'] = $_SESSION['jp']['FP_BALANCE_'.$selectDCC];
        } else {
            $crypto_class = new FaucetPay($settings['FP_API_KEY'], $selectDCC);
            $response = $crypto_class->getBalance();
            if ((isset($response)) && (is_array($response)) && ($response['status']==200)) {
                $_SESSION['jp']['FP_BALANCE_'.$selectDCC] = $response['balance'];
                $data['balance'] = $response['balance'];
            } else {
                $data['balance'] = 0;
            }
        }
    break;
}

echo json_encode($data);
