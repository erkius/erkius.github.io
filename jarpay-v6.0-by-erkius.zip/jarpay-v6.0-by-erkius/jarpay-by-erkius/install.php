<?php

/*

Created by MakeJar https://www.makejar.com/

*/

include 'includes/app.php';

// if installed then go to the index
if (is_file('includes/config.php')) {
    header('Location: .');
    exit;
}

unset($_SESSION['jp']);

$config_file = '';

switch ($act) {
    case 'install':
        $config_file = file_get_contents('includes/config_sample.php');
        foreach ($_POST as $field_name => $value) {
            if ($field_name=='password') {
                $value = hash('sha256', $value);
            }
            $config_file = str_replace('*'.$field_name.'*', $value, $config_file);
        }
        @file_put_contents('includes/config.php', $config_file);
        if (is_file('includes/config.php')) {
            header('Location: .');
            exit;
        }
    break;
}



//

include 'includes/template-top.php';

if (!empty($config_file)) {
    ?>
    <div class="center-box">
        <div class="text-center mb-4">
            <h1 class="h3 mb-3 font-weight-normal">Install <?php echo $jarpay_name; ?></h1>
            <p>Please create file <code>includes/config.php</code> including the following content:</p>
            <div style="text-align: left; font-size: 12px;background-color: #ffffff;padding: 5px; border: 1px dotted #000000;">
<?php
    highlight_string($config_file);
    ?>
            </div>
        </div>
    </div>
    <?php
} else {

// ask for password
?>

    <div class="center-box">
        <form class="form-center" method="post">
            <input type="hidden" name="act" value="install" />
            <div class="text-center mb-4">
                <img class="mb-4" src="images/jarpay.svg" alt="Jar Pay" width="72" height="72" />
                <h1 class="h3 mb-3 font-weight-normal"><?php echo $jarpay_name; ?> - Install</h1>
                <p>Please enter the details below</p>
            </div>

            <div class="link-gw"><a target="_blank" tabindex="-1" href="https://faucetpay.io/?r=8176">FaucetPay.io</a></div>
            <div class="form-label-group">
                <input type="input" autocomplete="off" name="fp_api_key" id="inputFPAPIKey" class="form-control" placeholder="FaucetPay - API Key" autofocus />
                <label for="inputFPAPIKey">FaucetPay - API Key</label>
            </div>

            <div class="form-label-group">
                <select name="default_currency_fiat" id="selectDCF" class="form-control" placeholder="Default Currency Fiat">
<?php
foreach ($currencies_fiat as $currency) {
    echo '<option value="'.$currency.'">'.$currency.'</option>';
}
?>
                </select>
                <label for="selectDCF">Default Currency Fiat</label>
            </div>

            <div class="form-label-group">
                <select name="default_currency_crypto" id="selectDCC" class="form-control" placeholder="Default Currency Crypto">
<?php
foreach ($currencies_crypto_array as $currency) {
    $selected = '';
    if ($currency == 'BTC') {
        $selected = ' selected="selected"';
    }
    echo '<option value="'.$currency.'"'.$selected.'>'.$currency.'</option>';
}
?>
                </select>
                <label for="selectDCC">Default Currency Crypto</label>
            </div>

            <div class="form-label-group">
                <input type="number" name="default_conversion_fee" id="defaultConversionFee" class="form-control" placeholder="Default Conversion Fee (in %)" value="0" />
                <label for="defaultConversionFee">Default Conversion Fee (in %)</label>
            </div>

            <div class="form-label-group">
                <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required />
                <label for="inputPassword">Password</label>
            </div>

            <div class="form-label-group">
                <input type="password" name="password_confirmation" id="inputPasswordConfirmation" class="form-control" placeholder="Password Confirmation" />
                <label for="inputPasswordConfirmation">Password Confirmation</label>
            </div>

            <button class="btn btn-lg btn-primary btn-block" type="submit">Install</button>
        </form>
    </div>
<script type="text/javascript">
function checkAllFields(gw) {
    if ($('#'+gw).val()!='') {
        return true;
    }
    return false;
}

var gateways = ['inputFPAPIKey'];

$(function() {
    $('.form-center').on('input', function() {
        var atLeastOne = false;
        for (var z=0; z<gateways.length; z++) {
            if (checkAllFields(gateways[z])) {
                atLeastOne = true;
                break;
            }
        }
        for (var z=0; z<gateways.length; z++) {
            $('#'+gateways[z])[0].setCustomValidity((!atLeastOne) ? 'At least one API key is needed.' : '');
        }
        $('#inputPasswordConfirmation')[0].setCustomValidity($('#inputPasswordConfirmation').val() != $('#inputPassword').val() ? 'Passwords do not match.' : '');
    });
});
</script>
<?php
}

include 'includes/template-bottom.php';

?>
