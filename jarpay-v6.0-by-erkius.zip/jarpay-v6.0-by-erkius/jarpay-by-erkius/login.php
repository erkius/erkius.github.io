<?php

/*

Created by MakeJar https://www.makejar.com/

*/

include 'includes/app.php';

// if not installed then go to the install
if (!is_file('includes/config.php')) {
    header('Location: install.php');
    exit;
}

switch ($act) {
    case 'login':
        if ((isset($_POST['password'])) && (hash('sha256', $_POST['password']) == $settings['PASSWORD'])) {
            $_SESSION['jp'] = [];
            $_SESSION['jp']['logged'] = time();
        }
        header('Location: .');
        break;
    case 'logout':
        unset($_SESSION['jp']);
        header('Location: .');
        break;
}

// if logged then go to the index
if (isset($_SESSION['jp']['logged'])) {
    header('Location: .');
    exit;
}

include 'includes/template-top.php';

// ask for password
?>
<div class="center-box">
    <form class="form-center" method="post">
        <input type="hidden" name="act" value="login" />
        <div class="text-center mb-4">
            <img class="mb-4" src="images/jarpay.svg" alt="Jar Pay" width="72" height="72" />
            <h1 class="h3 mb-3 font-weight-normal"><?php echo $jarpay_name; ?> - Login</h1>
            <p>Please enter your password</p>
        </div>

        <div class="form-label-group">
            <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required autofocus />
            <label for="inputPassword">Password</label>
        </div>

        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
    </form>
</div>
<?php

include 'includes/template-bottom.php';

?>