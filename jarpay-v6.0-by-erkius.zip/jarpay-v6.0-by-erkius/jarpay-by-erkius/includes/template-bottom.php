<footer class="text-muted" style="clear:both;">
    <div class="container">
        <p class="float-right">
           ©2023
        </p>
        <p></p>
    </div>
</footer>

</body>

</html>