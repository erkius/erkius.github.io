<?php

/*

Created by MakeJar https://www.makejar.com/

*/

$jarpay_name = 'Jar Pay';
$jarpay_version = '6.00';

session_start();

$settings = array();

if (is_file('includes/config.php')) {
    include 'includes/config.php';
}

include 'includes/services/faucetpay.php';

$act = '';

if (isset($_POST['act'])) {
    $act = $_POST['act'];
}

if (!isset($_SESSION['jp']['message'])) {
    $_SESSION['jp']['message'] = [];
}


$currencies_fiat = ['USD', 'EUR', 'GBP', 'CAD'];

$gateways_array = [];
$currencies_crypto_array = [];


if ((!isset($settings['FP_API_KEY'])) || (!empty($settings['FP_API_KEY']))) {
    $fpClass = new FaucetPayCurrencies();
    $gateways_array['FaucetPay'] = $fpClass->getCurrencies();
}

foreach ($gateways_array as $cryptos) {
    $currencies_crypto_array = array_unique(array_merge($currencies_crypto_array, $cryptos));
}
asort($currencies_crypto_array);
