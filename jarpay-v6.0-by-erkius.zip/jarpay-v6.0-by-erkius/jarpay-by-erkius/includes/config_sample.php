<?php

$settings['PASSWORD'] = '*password*';

//---

$settings['FP_API_KEY'] = '*fp_api_key*';

//---

$settings['DEFAULT_CURRENCY_FIAT'] = '*default_currency_fiat*';
$settings['DEFAULT_CURRENCY_CRYPTO'] = '*default_currency_crypto*';

$settings['DEFAULT_CONVERSION_FEE'] = '*default_conversion_fee*'; // 1 for 1%
